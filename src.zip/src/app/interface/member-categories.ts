export interface emberCategories {
  name: string
}
