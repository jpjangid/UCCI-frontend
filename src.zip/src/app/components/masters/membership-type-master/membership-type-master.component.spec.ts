import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MembershipTypeMasterComponent } from './membership-type-master.component';

describe('MembershipTypeMasterComponent', () => {
  let component: MembershipTypeMasterComponent;
  let fixture: ComponentFixture<MembershipTypeMasterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MembershipTypeMasterComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MembershipTypeMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
