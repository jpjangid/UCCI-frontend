import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TurnoverMasterComponent } from './turnover-master.component';

describe('TurnoverMasterComponent', () => {
  let component: TurnoverMasterComponent;
  let fixture: ComponentFixture<TurnoverMasterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TurnoverMasterComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TurnoverMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
