import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HWMFormComponent } from './hwm-form.component';

describe('HWMFormComponent', () => {
  let component: HWMFormComponent;
  let fixture: ComponentFixture<HWMFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HWMFormComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(HWMFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
