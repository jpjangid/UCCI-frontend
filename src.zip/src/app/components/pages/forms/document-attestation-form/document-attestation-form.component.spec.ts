import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DocumentAttestationFormComponent } from './document-attestation-form.component';

describe('DocumentAttestationFormComponent', () => {
  let component: DocumentAttestationFormComponent;
  let fixture: ComponentFixture<DocumentAttestationFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DocumentAttestationFormComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DocumentAttestationFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
