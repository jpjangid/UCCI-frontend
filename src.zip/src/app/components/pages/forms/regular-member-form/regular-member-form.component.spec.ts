import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RegularMemberFormComponent } from './regular-member-form.component';

describe('RegularMemberFormComponent', () => {
  let component: RegularMemberFormComponent;
  let fixture: ComponentFixture<RegularMemberFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RegularMemberFormComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RegularMemberFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
