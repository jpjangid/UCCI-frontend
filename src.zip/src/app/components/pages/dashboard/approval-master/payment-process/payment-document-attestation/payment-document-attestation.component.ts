import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payment-document-attestation',
  templateUrl: './payment-document-attestation.component.html',
  styleUrls: ['./payment-document-attestation.component.scss']
})
export class PaymentDocumentAttestationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
