import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PaymentDocumentAttestationComponent } from './payment-document-attestation.component';

describe('PaymentDocumentAttestationComponent', () => {
  let component: PaymentDocumentAttestationComponent;
  let fixture: ComponentFixture<PaymentDocumentAttestationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PaymentDocumentAttestationComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PaymentDocumentAttestationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
