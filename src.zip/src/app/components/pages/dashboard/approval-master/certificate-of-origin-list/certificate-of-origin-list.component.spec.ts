import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CertificateOfOriginListComponent } from './certificate-of-origin-list.component';

describe('CertificateOfOriginListComponent', () => {
  let component: CertificateOfOriginListComponent;
  let fixture: ComponentFixture<CertificateOfOriginListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CertificateOfOriginListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CertificateOfOriginListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
