import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DocumentAttestationListComponent } from './document-attestation-list.component';

describe('DocumentAttestationListComponent', () => {
  let component: DocumentAttestationListComponent;
  let fixture: ComponentFixture<DocumentAttestationListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DocumentAttestationListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DocumentAttestationListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
