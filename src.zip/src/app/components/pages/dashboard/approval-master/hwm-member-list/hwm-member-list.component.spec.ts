import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HwmMemberListComponent } from './hwm-member-list.component';

describe('HwmMemberListComponent', () => {
  let component: HwmMemberListComponent;
  let fixture: ComponentFixture<HwmMemberListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HwmMemberListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(HwmMemberListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
