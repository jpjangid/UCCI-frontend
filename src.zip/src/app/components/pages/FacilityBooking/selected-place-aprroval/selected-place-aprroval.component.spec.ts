import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SelectedPlaceAprrovalComponent } from './selected-place-aprroval.component';

describe('SelectedPlaceAprrovalComponent', () => {
  let component: SelectedPlaceAprrovalComponent;
  let fixture: ComponentFixture<SelectedPlaceAprrovalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SelectedPlaceAprrovalComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SelectedPlaceAprrovalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
