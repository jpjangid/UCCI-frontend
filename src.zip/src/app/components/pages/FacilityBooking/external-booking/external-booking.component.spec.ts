import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ExternalBookingComponent } from './external-booking.component';

describe('ExternalBookingComponent', () => {
  let component: ExternalBookingComponent;
  let fixture: ComponentFixture<ExternalBookingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ExternalBookingComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ExternalBookingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
